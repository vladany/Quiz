package edu.fra.uas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizSocialApplicationTests {

	@Test
	void contextLoads() {
	}

}
